package Airline_Reservation;

public class Plane {
	private int planeNo;
	private String Firstclass;
	private int capacity;
	
	Plane(int no,String Firstclass,int cap){
		this.planeNo = no;
		this.Firstclass = Firstclass;
		this.capacity = cap;
	}
	public int getplaneNo() {
		return planeNo;
	}
	public String isFirstclass() {
		return Firstclass;
	}
	public int getcapacity() {
		return capacity;
	}
	public void setplaneNo(int no) {
		planeNo = no;
	}
	public void setFirstclass(String val) {
		Firstclass = val;
	}
	public void setcapacity(int cap) {
		capacity = cap;
	}
	public void displayplaneinfo() {
		System.out.println("plane No: "+ planeNo +"   First Class: "+ Firstclass +"  Total capacity: "+ capacity);
	}

}
