package Airline_Reservation;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Booking {
	String passengerName;
	int PlaneNo;
	String aadharNo;
	Date date;
	
	Booking(){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Name of passenger :");
		passengerName = scanner.next();
		System.out.println("Enter Plane No:");
		PlaneNo = scanner.nextInt();
		System.out.println("Enter your aadharNo:");
		aadharNo = scanner.next();
		System.out.println("Enter date dd/mm/yyyy");
		String dateInput = scanner.next();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Booking amount is Rs.1200");
		
		try {
			date = dateFormat.parse(dateInput);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public boolean isAvailable(ArrayList<Booking> bookings, ArrayList<Plane> planes) {
		int capacity = 0;
		for(Plane plane:planes) {
			if(plane.getplaneNo() == PlaneNo)
				capacity = plane.getcapacity();
		}
		int booked = 0;
		for(Booking b:bookings) {
			if(b.PlaneNo == PlaneNo && b.date.equals(date)) {
				booked++;
			}
		}
		return booked < capacity ? true:false;
	}	
}