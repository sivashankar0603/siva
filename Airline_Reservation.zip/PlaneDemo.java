package Airline_Reservation;

import java.util.Scanner;
import java.util.ArrayList;

public class PlaneDemo {

	public static void main(String[] args) {
		
		ArrayList<Plane> planes = new ArrayList<Plane>();
		ArrayList<Booking> bookings = new ArrayList<Booking>();
		
		planes.add(new Plane(1,"Yes",2));
		planes.add(new Plane(2,"No",100));
		planes.add(new Plane(3,"No",90));
		planes.add(new Plane(4,"Yes",110));
		
		int useropt =1;
		Scanner scanner = new Scanner(System.in);
		
		for(Plane p:planes) {
			p.displayplaneinfo();
		}
		
		while(useropt ==1) {
			System.out.println("Enter 1 to book ");
			useropt = scanner.nextInt();
			if(useropt == 1) {
				Booking Booking = new Booking(); 
				if(Booking.isAvailable(bookings,planes)) {
					bookings.add(Booking);
					System.out.println("Your Booking is Confirmed");
					
				}
				else
					System.out.println("sorry..Plane is full.Try another Plane or date");
			}
		if(useropt > 1)
			break;
		
		int user = 3;
		System.out.println("Enter 3 to cancel Booking");
		scanner.nextInt();
		if(user == 3) {
			System.out.println("Your Booking is cancelled");
		}
		}
   }
}
